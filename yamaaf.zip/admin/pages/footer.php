<footer class="main-footer">
    <div class="float-right d-none d-sm-inline">
        PANEL ADMIN
    </div>
    <strong>Copyright &copy; 2023 KELOMPOK 2 PABW TI-4A</strong> All rights reserved.
</footer>