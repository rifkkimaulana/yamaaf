<?php
header("Location: dashboard.php?page=dashboard");
exit;
?>